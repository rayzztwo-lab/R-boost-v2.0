package com.gameturbo.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Pembacaan sistem yang dipakai bersama oleh lobby, panel, screenshot dan perekam. */
object Sys {

    private fun readLong(path: String): Long? = try {
        File(path).readText().trim().split(" ")[0].toLong()
    } catch (e: Exception) {
        null
    }

    /** Rata-rata clock CPU saat ini dibanding clock maksimum (persen). -1 kalau tidak terbaca. */
    fun cpuPct(): Int {
        var sum = 0.0
        var n = 0
        for (i in 0 until 16) {
            val b = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            val c = readLong(b + "scaling_cur_freq") ?: continue
            val m = readLong(b + "cpuinfo_max_freq") ?: continue
            if (m > 0L) {
                sum += c.toDouble() / m.toDouble()
                n++
            }
        }
        return if (n == 0) -1 else (sum / n * 100.0).toInt().coerceIn(0, 100)
    }

    /** Beban/clock GPU (persen) kalau HP mengizinkan dibaca. -1 kalau tidak. */
    fun gpuPct(): Int {
        readLong("/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage")?.let { return it.toInt().coerceIn(0, 100) }
        readLong("/sys/kernel/gpu/gpu_busy")?.let { return it.toInt().coerceIn(0, 100) }
        val dirs = ArrayList<String>()
        dirs.add("/sys/class/kgsl/kgsl-3d0/devfreq/")
        try {
            File("/sys/class/devfreq").listFiles()?.forEach {
                val n = it.name.lowercase()
                if (n.contains("gpu") || n.contains("mali") || n.contains("kgsl")) dirs.add(it.path + "/")
            }
        } catch (_: Exception) {
        }
        for (d in dirs) {
            val c = readLong(d + "cur_freq") ?: continue
            val m = readLong(d + "max_freq") ?: continue
            if (m > 0L) return (c * 100L / m).toInt().coerceIn(0, 100)
        }
        return -1
    }

    fun realSize(ctx: Context): Pair<Int, Int> {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            return Pair(b.width(), b.height())
        }
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        return Pair(m.widthPixels, m.heightPixels)
    }

    fun a11yEnabled(ctx: Context): Boolean {
        val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains("RbAccessibilityService")
    }

    fun storageGb(): Pair<Double, Double> {
        return try {
            val st = android.os.StatFs(Environment.getDataDirectory().path)
            val free = st.availableBytes / 1073741824.0
            val total = st.totalBytes / 1073741824.0
            Pair(free, total)
        } catch (e: Exception) {
            Pair(-1.0, -1.0)
        }
    }

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    fun savePng(ctx: Context, bmp: Bitmap): Boolean {
        return try {
            val name = "RBOOST_" + stamp() + ".png"
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues()
                v.put(MediaStore.Images.Media.DISPLAY_NAME, name)
                v.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/RBoost")
                val u = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
                if (u == null) {
                    false
                } else {
                    ctx.contentResolver.openOutputStream(u)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    true
                }
            } else {
                val d = ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
                File(d, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    fun videoName(): String = "RBOOST_" + stamp() + ".mp4"
}
